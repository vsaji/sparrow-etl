var data;
var editor;

$.getJSON("https://raw.githubusercontent.com/vsaji/saji-practices/master/project_00.json", function (json) {
    data = json; // this will show the info it in firebug console
});

$(document).ready(function () {
    addHomePage();
    addDeploymentPage();
    loadAll();
    const container = document.getElementById('jsoneditor')
    const options = {
       mode: 'preview'
    }
    editor = new JSONEditor(container, options, responseJson);
});


previousVisit = "#home_container";

function addHomePage(){
    var html1="<div id=\"home_container\"><div class=\"title-grid\"><div class=\"title-left\">Home</div></div><div><img src=\"setup-process.png\" /></div></div>";
    document.getElementById("page-container").innerHTML=html1;
}

function addDeploymentPage(){
    var html1="<div id=\"deployment_container\"><div class=\"title-grid\"><div class=\"title-left\">Deployment</div><div class=\"title-right\"><span class=\"button1\" onclick=\"saveDeployment()\">Save</span>"
    html1+="<!--span class=\"button1\">Reset</span--></div></div><div><form class=\"form-style-7\" id=\"deployment_form\"><ul><span class=\"button1\" onclick=\"addConfig('targetConfig','template.targetConfig')\">+</span> Add Targets<div id=\"_targetConfig\" class=\"subPanel\"><input type=\"hidden\" name=\"repeat\" value=\"targetConfig\"></div>"
    html1+="<span class=\"button1\" onclick=\"addConfig('commonParameter','template.commonParameter')\">+</span> Add Common Parameters<div id=\"_commonParameter\" class=\"subPanel\"><input type=\"hidden\" name=\"repeat\" value=\"commonParameter\"></div></ul></form></div></div>"
    $("#page-container").append(html1);    
    $("#deployment_container").hide();
}


var responseJson = {};

function loadAll() {
    buildNavigation();
    buildPage();
    buildFormForEachContainer()
}


function buildNavigation() {
    var navItemHtml = "";
    $.each(data, function (i, v) {
        if (v.menuInfo !== undefined) {
            navItemHtml+= "<li><a href=\"javascript:showPage('" + i + "');\"><i class=\"fa icon " + v.menuInfo.faIcon + "\"></i>" + v.menuInfo.displayName + "</a></li>";
        }
    });
    document.getElementById("nav-item-container").innerHTML=navItemHtml;
}

function buildPage() {
    var html = "";
    $("#deployment_container").hide();
    $.each(data, function (i, v) {
        if (document.getElementById(i + "_container") == null && v.menuInfo !== undefined) {
            html = "<div id=\"" + i + "_container\">"
            html += "<div class=\"title-grid\">";
            html += "<div class=\"title-left\">";
            html += v.menuInfo.pageTitle + "</div>"
            html += "<div class=\"title-right\">"
            html += "      <span class=\"button1\" onClick=\"save('"+i+"')\">Save</span>"
            //html += "     <span class=\"button1\">Reset</span>"
            html += "</div></div></div>"
            $("#page-container").append(html);
            $("#" + i + "_container").hide();
        }
    });
}

function save(pageName){
    var formElement =document.getElementById(pageName+"_form").elements;


    if(formElement.namedItem("repeat")!=null){
           saveRepeat(formElement,pageName);
    }else{
        saveSingle(formElement,pageName);
    }
    editor.set(responseJson);
}


function saveDeployment(){
    responseJson.deployment={};
    responseJson.deployment.targetConfig=[];


     var targetGroup = $("#targetConfig_sub.subConfigBox");

    for(i=0; i<targetGroup.length; i++){
        fromGrp=$(targetGroup[i]).find(":input")
        var entry={};
        for(j=0; j<fromGrp.length; j++){
            if(fromGrp[j].name=="repeat"){
                entry.envParams={};
                populateParams(j+1,fromGrp,entry.envParams)
                break;
            }
            populateEntry(fromGrp[j],entry);
        }
        eval("responseJson.deployment.targetConfig.push(entry);");
    }

    if(document.getElementById("commonParameter_sub")!=null){
        responseJson.deployment.commonParameter={};
        var commonParamGrp = $("#commonParameter_sub.subConfigBox").find(":input");
        populateParams(0,commonParamGrp,responseJson.deployment.commonParameter);
    }

    //alert($("#_envParams :input").length)
    //alert($("#_commonParameter :input").length)

    editor.set(responseJson);

}

function populateParams(idx,formElement,entryObj){
    for(;idx<formElement.length;){
        eval("entryObj."+formElement[idx].value+"=\""+formElement[(idx+1)].value+"\"");
        idx+=2;
    }
}

function populateEntry(formElement,entryObj){
    switch(formElement.type){
        case "select":
        case "select-one":
        case "textarea":
        case "text":
            eval("entryObj."+formElement.name+"='"+formElement.value+"'");
        break;
        case "checkbox":
            eval("entryObj."+formElement.name+"="+formElement.checked)
        break;
    }
}



function saveRepeat(formElement,pageName){
    eval("responseJson."+pageName+"=[];")
    var firstElement = formElement[1].name;
    var pushed=false;
    var entry={};
    for(i=1; i<formElement.length; i++){
        
        if(i>1 && formElement[i].name==firstElement){
            eval("responseJson."+pageName+".push(entry);");
            eval("entry={}");
        }

        switch(formElement[i].type){
            case "select":
            case "select-one":                
            case "textarea":
            case "text":
                eval("entry."+formElement[i].name+"='"+formElement[i].value+"'");
            break;
            case "checkbox":
                eval("entry."+formElement[i].name+"="+formElement[i].checked)
            break;
        }
    }
    eval("responseJson."+pageName+".push(entry);");
    editor.set
}


function saveSingle(formElement,pageName){
    eval("responseJson."+pageName+"={};")
    for(i=0; i<formElement.length; i++){
        switch(formElement[i].type){
            case "select":
            case "textarea":
            case "text":
                eval("responseJson."+pageName+"."+formElement[i].name+"='"+formElement[i].value+"'");
            break;
            case "checkbox":
                eval("responseJson."+pageName+"."+formElement[i].name+"="+formElement[i].checked)
            break;
        }
    }
}


function buildFormForEachContainer() {

    $.each(data, function (i, v) {

        if (v.menuInfo !== undefined && v.fields !== undefined && v.menuInfo.skipAutoRendering===undefined) {
            
            console.log("buildFormForEachContainer==>"+i);

            html = "<div><form class=\"form-style-7\" id=\""+i+"_form\"><ul>";
            $.each(v.fields, function (j, c) {
                html += renderForm(j, c);
            });
            html += "</ul></form></div>";
            $("#" + i + "_container").append(html);
        }

    });
}

function renderForm(j, c) {
    tempHtml = "";
    switch (c.type) {
        case "template-single":
            tempHtml += singleFromTemplate(j, c);
            break;
        case "template-repeat":
            console.log(j)
            tempHtml += repeatFromTemplate(j, c);
            break;
        default:
            tempHtml += "<li><label for=\"name\">" + c.label + "</label>";
            tempHtml += resolveInput(j, c);
            if (c.note !== undefined) {
                tempHtml += "<span>" + c.note + "</span>";
            }
            tempHtml += "</li>";
            break;
    }
    return tempHtml
}


function repeatFromTemplate(name, control) {
    if (control.valueOptions != null) {
        control.type = "select";
        return renderForm(name, control) + "<li></li>";
    }

    ref=null;
    if(control.nestedNode!==undefined){
        ref="this";
    }
    html = "<span class=\"button1\" onClick=\"addConfig('" + name + "','" + control.template + "',"+ref+")\">+</span> Add " + control.label;
    html += "<div id=\"_" + name + "\" class=\"subPanel\"><input type='hidden' name='repeat' value='"+name+"'></div>";
    return html;
}


function addConfig(name, template,ref) {
    html = "<div id=\"" + name + "_sub\" class=\"subConfigBox\">";
    html += "<span class=\"closeButton\" onClick=\"this.parentNode.remove()\"></span>";
    refObj = eval("data." + template);
    html += singleFromTemplate(name, refObj)
    html += "</div>";
    if(ref!=null){
        $(ref.parentElement).find("#_" + name).append(html);
    }else{
        $("#_" + name).append(html);
    }
}

function singleFromTemplate(name, control) {
    if (control.templateRef !== undefined) {
        if (control.templateRef.startsWith("this.value")) {
            refSub = control.value;
        } else {
            refSub = eval("data." + control.templateRef);
        }
        refObj = eval("data." + control.template + "." + refSub);
    } else if (control.template !== undefined) {
        refObj = eval("data." + control.template);
    } else {
        refObj = control;
    }

    html = "";
    $.each(refObj, function (j, c) {
        html += renderForm(j, c);
    });
    return html;
}

/**
 * 
 * 
 * */
function resolveInput(name, control) {
    pref = "";

    switch (control.type) {
        case "text":
            value = control.value === undefined ? "" : control.value;
            if (control.readOnly) {
                pref = "readonly";
            }
            return "<input type=\"text\" name=\"" + name + "\" maxlength=\"100\" value=\"" + value + "\" " + pref + ">";
        case "secure":
            return "<input type=\"password\" name=\"" + name + "\" maxlength=\"100\">";
        case "checkbox":
            checked = control.value == "checked" ? control.value : "";
            return "<input type=\"checkbox\" name=\"" + name + "\" " + checked + ">";
        case "multi":
        case "select":
        case "select-one":            
            if (control.type == "multi") {
                pref = "multiple";
            } else {
                pref = "style='height:30px'";
            }

            inputEvent=""
            if(control.event !== undefined){
                inputEvent=control.event
            }
            selectHtml = "<select data-placeholder=\"Begin typing a name to filter...\" " + pref + " name=\""+name+"\" "+inputEvent+">";

            if(control.valueOptionsRef!==undefined){
                options=jsonPath(responseJson,control.valueOptionsRef);
            }else{
                options=control.valueOptions;
            }

            $.each(options, function (idx, item) {
                selectHtml += "<option value=\"" + item + "\">" + item + "</option>";
            });
            selectHtml += "</select>";
            return selectHtml;
        default:
            return control.type;
    }
}


function showTemplate(control,obj){
    var html=singleFromTemplate(obj.value, eval(control+"."+obj.value));
    if($(obj.parentElement.parentElement).children('div').html()===undefined){
        $(obj.parentElement.parentElement).append("<div style='border-top: 1px solid white;padding-top:20px' id=\""+control+"\">aad</div>");
    }

    $(obj.parentElement.parentElement).children('div').html(html);
}


function showPage(name) {
    pageName = "#" + name + "_container";
    if (previousVisit == null) {
        previousVisit = pageName;
    } else {
        $(previousVisit).hide();
        previousVisit = pageName;
    }
    $(previousVisit).show();
}

/***********************************JSONPath********************************************************* */

function jsonPath(obj, expr, arg) {
    var P = {
       resultType: arg && arg.resultType || "VALUE",
       result: [],
       normalize: function(expr) {
          var subx = [];
          return expr.replace(/[\['](\??\(.*?\))[\]']/g, function($0,$1){return "[#"+(subx.push($1)-1)+"]";})
                     .replace(/'?\.'?|\['?/g, ";")
                     .replace(/;;;|;;/g, ";..;")
                     .replace(/;$|'?\]|'$/g, "")
                     .replace(/#([0-9]+)/g, function($0,$1){return subx[$1];});
       },
       asPath: function(path) {
          var x = path.split(";"), p = "$";
          for (var i=1,n=x.length; i<n; i++)
             p += /^[0-9*]+$/.test(x[i]) ? ("["+x[i]+"]") : ("['"+x[i]+"']");
          return p;
       },
       store: function(p, v) {
          if (p) P.result[P.result.length] = P.resultType == "PATH" ? P.asPath(p) : v;
          return !!p;
       },
       trace: function(expr, val, path) {
          if (expr) {
             var x = expr.split(";"), loc = x.shift();
             x = x.join(";");
             if (val && val.hasOwnProperty(loc))
                P.trace(x, val[loc], path + ";" + loc);
             else if (loc === "*")
                P.walk(loc, x, val, path, function(m,l,x,v,p) { P.trace(m+";"+x,v,p); });
             else if (loc === "..") {
                P.trace(x, val, path);
                P.walk(loc, x, val, path, function(m,l,x,v,p) { typeof v[m] === "object" && P.trace("..;"+x,v[m],p+";"+m); });
             }
             else if (/,/.test(loc)) { // [name1,name2,...]
                for (var s=loc.split(/'?,'?/),i=0,n=s.length; i<n; i++)
                   P.trace(s[i]+";"+x, val, path);
             }
             else if (/^\(.*?\)$/.test(loc)) // [(expr)]
                P.trace(P.eval(loc, val, path.substr(path.lastIndexOf(";")+1))+";"+x, val, path);
             else if (/^\?\(.*?\)$/.test(loc)) // [?(expr)]
                P.walk(loc, x, val, path, function(m,l,x,v,p) { if (P.eval(l.replace(/^\?\((.*?)\)$/,"$1"),v[m],m)) P.trace(m+";"+x,v,p); });
             else if (/^(-?[0-9]*):(-?[0-9]*):?([0-9]*)$/.test(loc)) // [start:end:step]  phyton slice syntax
                P.slice(loc, x, val, path);
          }
          else
             P.store(path, val);
       },
       walk: function(loc, expr, val, path, f) {
          if (val instanceof Array) {
             for (var i=0,n=val.length; i<n; i++)
                if (i in val)
                   f(i,loc,expr,val,path);
          }
          else if (typeof val === "object") {
             for (var m in val)
                if (val.hasOwnProperty(m))
                   f(m,loc,expr,val,path);
          }
       },
       slice: function(loc, expr, val, path) {
          if (val instanceof Array) {
             var len=val.length, start=0, end=len, step=1;
             loc.replace(/^(-?[0-9]*):(-?[0-9]*):?(-?[0-9]*)$/g, function($0,$1,$2,$3){start=parseInt($1||start);end=parseInt($2||end);step=parseInt($3||step);});
             start = (start < 0) ? Math.max(0,start+len) : Math.min(len,start);
             end   = (end < 0)   ? Math.max(0,end+len)   : Math.min(len,end);
             for (var i=start; i<end; i+=step)
                P.trace(i+";"+expr, val, path);
          }
       },
       eval: function(x, _v, _vname) {
          try { return $ && _v && eval(x.replace(/@/g, "_v")); }
          catch(e) { throw new SyntaxError("jsonPath: " + e.message + ": " + x.replace(/@/g, "_v").replace(/\^/g, "_a")); }
       }
    };
 
    var $ = obj;
    if (expr && obj && (P.resultType == "VALUE" || P.resultType == "PATH")) {
       P.trace(P.normalize(expr).replace(/^\$;/,""), obj, "$");
       return P.result.length ? P.result : false;
    }
 }
